
public class Project6 {

	public static void main(String[] args) 
	{
		int num;
		
		num=3;
		
		System.out.println("�ܼ�num���ȬO"+num);
	}
}
